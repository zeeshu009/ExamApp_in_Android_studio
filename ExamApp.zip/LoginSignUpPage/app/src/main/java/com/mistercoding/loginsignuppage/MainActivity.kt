package com.mistercoding.loginsignuppage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.mistercoding.loginsignuppage.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener(){
            intent = Intent(this,Exam::class.java)

            if(binding.user.text.toString() == "zeeshu" && binding.password.text.toString()=="123"){
                startActivity(intent);

            }
            else
                Toast.makeText(this,"Invalid UserName or Password ",Toast.LENGTH_LONG).show()
        }
    }
}