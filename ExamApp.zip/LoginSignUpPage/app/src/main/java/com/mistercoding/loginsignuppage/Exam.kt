package com.mistercoding.loginsignuppage

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.mistercoding.loginsignuppage.databinding.ActivityExamBinding

class Exam : AppCompatActivity()
{
    lateinit var binding : ActivityExamBinding
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityExamBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button2.setOnClickListener(){
            val choices = arrayOf("Kotlin","C++","Java","Python","C","None")
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Which is your Favorite Language ")
            builder.setSingleChoiceItems(choices,0,DialogInterface.OnClickListener { dialog, which -> })
            builder.setPositiveButton("Submit",DialogInterface.OnClickListener { dialog, which ->  })
            builder.setNegativeButton("Decline",DialogInterface.OnClickListener { dialog, which ->  })
            builder.show()

        }
        binding.button3.setOnClickListener(){
            val choices = arrayOf("Android Development","Web Development","Machine Learning","Deep Learning","None")
            val builder = AlertDialog.Builder(this)
            builder.setTitle("How many technologies you know?")
            builder.setMultiChoiceItems(choices,null,DialogInterface.OnMultiChoiceClickListener { dialog, which, isChecked ->  })
            builder.setPositiveButton("Submit",DialogInterface.OnClickListener { dialog, which ->  })
            builder.setNegativeButton("Decline",DialogInterface.OnClickListener { dialog, which ->  })
            builder.show()
        }
        binding.button4.setOnClickListener(){
            val builder = AlertDialog.Builder(this)
            builder.setTitle("are you sure ?")
            builder.setMessage("Do you want to close this Screen?")
            builder.setIcon(R.drawable.sharp_chip_extraction_24)
            builder.setPositiveButton("Yes",DialogInterface.OnClickListener { dialog, which ->

                finish()
            })
            builder.setNegativeButton("No",DialogInterface.OnClickListener { dialog, which ->

            })
            builder.show()
        }
        binding.button5.setOnClickListener(){
            val builder = AlertDialog.Builder(this)
            builder.setTitle("are you sure ?")
            builder.setMessage("Do you want to close this App?")
            builder.setIcon(R.drawable.sharp_chip_extraction_24)
            builder.setPositiveButton("Yes",DialogInterface.OnClickListener { dialog, which ->

                finishAffinity()

            })
            builder.setNegativeButton("No",DialogInterface.OnClickListener { dialog, which ->

            })
            builder.show()
        }
    }
}